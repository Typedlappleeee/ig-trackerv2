# Handoff : Redesign ScaleFlow (site + app)

## Overview

Redesign complet de **ScaleFlow** (`Typedlappleeee/ig-trackerv2`, branche `main`) :

1. **La landing page** (`website/`) — refonte visuelle complète, contenu conservé mot pour mot.
2. **L'application** (`electron-app/`) — refonte du shell (sidebar) et des écrans principaux, sans changer les fonctionnalités ni la structure de navigation existante.

Objectif : garder l'identité dark violet/cyan de ScaleFlow mais dans une version beaucoup plus soignée — hiérarchie typographique nette, cartes cohérentes, animations discrètes, densité maîtrisée.

## À propos des fichiers de design

⚠️ **Les fichiers HTML de ce bundle sont des références de design, pas du code de production.**

Ce sont des prototypes qui montrent l'apparence et le comportement voulus. Ils sont écrits en HTML/CSS inline avec un petit runtime maison (`support.js`) — **ne pas les copier tels quels dans le repo**.

La tâche est de **recréer ces designs dans l'environnement existant de ScaleFlow** :
- Landing : **React + Vite + Tailwind** (`website/`), en réutilisant `website/tailwind.config.js`.
- App : **React + Vite + Electron** (`electron-app/`), en réutilisant les classes du design system maison (`sf-card`, `sf-btn`, `sf-badge`, `sf-page-header`, `sf-page-title`, `sf-section-label`, `sf-status-chip`, `sf-empty`, `sf-skeleton`, `sf-tabs`/`sf-tab`, variables CSS `--text-1`…`--text-4`, `--surface`, `--border`, `--accent`, `--ok`, `--warn`, `--danger`, `--r-*`, `--sp-*`, `--t-*`, `--elev-*`) définies dans `electron-app/src/index.css`.

Les valeurs exactes (hex, tailles, rayons) sont données plus bas pour que le rendu soit fidèle. Là où une variable CSS existante correspond, **préférer la variable** à la valeur brute.

## Fidélité

**High-fidelity.** Couleurs, typographies, espacements et interactions sont définitifs. Recréer l'UI au pixel près en utilisant les composants et classes déjà présents dans le codebase.

## Design Tokens

### Couleurs — app et landing (identiques)

| Rôle | Valeur |
|---|---|
| Fond base | `#06060E` |
| Fond surélevé (cartes) | `rgba(255,255,255,0.025)` |
| Fond carte accentuée | `linear-gradient(160deg, rgba(<accent>,0.09), rgba(255,255,255,0.015))` |
| Bordure | `rgba(255,255,255,0.08)` |
| Bordure accentuée | `rgba(139,92,246,0.35)` |
| Texte 1 | `#F2F0FF` |
| Texte 2 | `rgba(196,181,253,0.72)` |
| Texte 3 | `rgba(196,181,253,0.6)` |
| Texte 4 (muted) | `rgba(148,163,184,0.55)` |
| Accent violet | `#8B5CF6` / clair `#C4B5FD` / très clair `#E9D5FF` |
| Accent indigo | `#818CF8` / clair `#A5B4FC` / `#C7D2FE` |
| Accent cyan | `#22D3EE` / clair `#67E8F9` |
| Succès | `#34D399` (clair `#A7F3D0`) |
| Warning | `#FCD34D` / `#FBBF24` |
| Danger | `#F87171` |
| Orange (warmup) | `#FB923C` (clair `#FED7AA`) |
| Rose (studio/remix) | `#EC4899` / `#F472B6` / `#FBCFE8` |

### Dégradé de marque

```css
linear-gradient(135deg, #22D3EE, #818CF8, #A855F7)
```
Utilisé pour : boutons primaires, logo, chiffres mis en avant (via `background-clip: text`).

Variantes par outil :
- Reels / Remix : `linear-gradient(135deg,#6366F1,#8B5CF6)`
- Story / Mixer : `linear-gradient(135deg,#8B5CF6,#A78BFA)`
- TikTok : `linear-gradient(135deg,#06B6D4,#3B82F6)`
- Warmup : `linear-gradient(135deg,#F59E0B,#EF4444)` (barres : `linear-gradient(90deg,#FB923C,#F97316)`)
- Power on : `linear-gradient(135deg,#10B981,#059669)`
- Power off / neutre : `linear-gradient(135deg,#64748B,#475569)`
- Cross-posting : `linear-gradient(135deg,#4F46E5,#6366F1)`
- Threads : `linear-gradient(135deg,#111,#333)`

### Typographie

- **Display** : `'Space Grotesk'`, weights 500/600/700. Titres de page, chiffres, noms de section.
- **Corps** : `'Manrope'`, weights 400/500/600/700/800. Tout le reste.
- **Mono** : `monospace` (noms de téléphones, IP, proxies, logs, badges techniques).

Échelle :

| Usage | Taille | Weight | Letter-spacing |
|---|---|---|---|
| H1 landing hero | 76px | 700 | -0.03em |
| H1 landing section | 46px | 700 | -0.02em |
| H1 page app | 30–34px | 700 | -0.02em |
| H2 sous-section app | 26px | 700 | -0.02em |
| Titre de carte | 14–15px | 700 | — |
| Titre carte outil | 19px | 700 | -0.01em |
| Corps | 13–14px | 600 | — |
| Corps landing | 15–16px | 400/600 | — |
| Label section (uppercase) | 10.5–11px | 800 | 0.1–0.2em |
| Badge / chip | 10.5–12px | 800 | 0.06–0.14em si uppercase |
| Mono technique | 10.5–12px | 700 | — |
| KPI chiffre | 26–34px | 700 | -0.02em, `font-variant-numeric: tabular-nums` |

Line-height : 1.6–1.7 pour les paragraphes, 1.02–1.15 pour les titres.

### Espacement

Padding de page : `32px 32px 80px`. Largeur max de contenu : `1120px` (app) / `1140px` (landing), centré.
Gaps : `6px` (chips serrés), `8px`, `10px`, `12px`, `14px` (grilles de cartes), `16px` (colonnes), `20–26px` (blocs).
Padding de carte : `18px` (KPI), `22px` (standard), `24–28px` (large).

### Rayons

`6px` cellules calendrier · `8–9px` petits badges/icônes · `10–12px` boutons et inputs · `13–14px` cartes internes · `16–18px` cartes · `20–22px` cartes outils et modales · `99px` pills.

### Ombres

- Carte au survol : `0 20px 46px -20px rgba(0,0,0,0.6)`
- Carte outil au survol : `0 22px 50px -22px rgba(0,0,0,0.65)`
- Bouton primaire : `0 0 28px -8px rgba(129,140,248,0.7)` (survol : `0 0 44px -6px rgba(129,140,248,1)`)
- Modale : `0 40px 90px -30px rgba(0,0,0,0.8)`
- Barre d'actions flottante : `0 20px 50px -16px rgba(124,58,237,0.5)`
- Mockup landing : `0 40px 100px -30px rgba(124,58,237,0.45), inset 0 1px 0 rgba(255,255,255,0.08)`

### Animations

```css
@keyframes sfPulse  { 0%,100%{opacity:1;transform:scale(1)} 50%{opacity:.4;transform:scale(.75)} }
@keyframes sfUp     { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
@keyframes sfAurora { 0%,100%{transform:translate(0,0) scale(1);opacity:.5} 50%{transform:translate(3%,-4%) scale(1.06);opacity:.75} }
@keyframes sfMarquee{ 0%{transform:translateX(0)} 100%{transform:translateX(-50%)} }
@keyframes sfShine  { 0%,100%{background-position:0% 50%} 50%{background-position:100% 50%} }
```

- Entrée de page / de section : `sfUp 0.4–0.5s ease both`
- Points de statut « en cours » / « en ligne » : `sfPulse 1.4–2.4s ease-in-out infinite`
- Halos d'ambiance en fond : `sfAurora 18–24s ease-in-out infinite`, `filter: blur(100–110px)`, opacité 0.08–0.14
- Survol de carte : `transform: translateY(-3px|-4px)` + ombre, `transition: transform .25s ease, box-shadow .25s ease, border-color .25s ease`
- Accordéon FAQ : `grid-template-rows: 0fr → 1fr`, `transition .3s ease`
- Barres de progression : `transition: width .3s–.6s ease`

Respecter `prefers-reduced-motion` (le codebase le fait déjà dans `index.css`).

### Scrollbars (important sur fond sombre)

```css
* { scrollbar-width: thin; scrollbar-color: rgba(139,92,246,0.3) transparent; }
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 99px; }
::-webkit-scrollbar-track { background: transparent; }
```

---

# PARTIE 1 — Landing page (`website/`)

Fichier de référence : `ScaleFlow Redesign v2.dc.html`.

Le **contenu est celui du site actuel, mot pour mot** (headline, sous-titres, features, tarifs, FAQ, footer). Seuls les témoignages ont changé : ils sont maintenant au nom d'agences.

### Sections, dans l'ordre

1. **Nav** — sticky, pill flottante `max-width:1140px`, `padding:12px 20px`, `border-radius:18px`, fond `rgba(10,10,24,0.72)`, `backdrop-filter: blur(20px)`, bordure `rgba(255,255,255,0.09)`, ombre `0 8px 32px -12px rgba(0,0,0,0.6)`. Logo (tuile 32px dégradé de marque + « Scale » blanc / « Flow » en dégradé), 4 liens (Fonctionnalités, Comment ça marche, Tarifs, FAQ), bouton ghost « Télécharger », bouton primaire « Commencer → ».
2. **Hero** — centré. Badge pill (point vert pulsant + « Automatisation Instagram & TikTok multi-comptes »), H1 76px avec « 100+ comptes » en dégradé cyan animé (`sfShine 6s`) et « un seul clic » en dégradé indigo→rose, sous-titre 18px, deux CTA, trois micro-réassurances (✓ Sans carte bancaire · Windows, Mac & Web · Setup en < 5 min).
3. **Stats** — 3 cartes glass (`max-width:680px`) avec compteurs animés de 0 à la cible sur 1400ms, easing `1-(1-p)³` : 100+, 1 M+ (format compact `fr-FR`), 15h.
4. **Mockup de l'app** — fenêtre macOS (3 feux, titre, badge « 52 phones en ligne ») montrant l'écran Mass Posting : sidebar avec item actif + jauge de crédits, stepper de 3 pastilles, 4 lignes de téléphones avec statuts (publié / en cours pulsant / en file), bouton « ⚡ Lancer la diffusion sur 52 comptes ». Halo animé au-dessus.
5. **Marquee** — bande défilante `sfMarquee 34s linear infinite`, items séparés par un point en dégradé, liste dupliquée pour la boucle.
6. **Features** — grille 3 colonnes, en-tête centré. 8 cartes : Mass Posting (span 2), Programmation, Captions IA, Remix & Repurpose (span 2), Auto-Warmup, Cloud Phones GeeLark, Collaboration d'équipe, Crédits à la demande (span 2, layout horizontal). Chaque carte a un mini-aperçu illustratif (pills de téléphones, mini-calendrier 21 cellules, exemple de caption, ratios vidéo 9:16/1:1/16:9 + barres, jauges de warmup, lignes de statut, badges de rôles, solde).
7. **Comment ça marche** — 3 cartes numérotées 01/02/03, numéro en dégradé.
8. **Témoignages** — bande à fond `rgba(124,58,237,0.04)` avec liseré haut/bas. 3 cartes : gros chiffre en dégradé (+340%, 90%+, 15h), citation, auteur = **nom d'agence en majuscules** avec initiales dans un avatar dégradé.
   - AGENCE GROWTHPULSE — Agence Growth · 120 comptes — avatar `GP`
   - AGENCE UGC LAB — Contenu UGC · 45 comptes — avatar `UL`
   - AGENCE SCALEUP MEDIA — SMMA · 300+ comptes — avatar `SM`
9. **Tarifs** — 3 plans. Le plan Pro est mis en avant par une **bordure en dégradé** (wrapper `padding:2px` avec le dégradé de marque, enfant `border-radius:20px; background:#0A0A1C`), badge « Populaire ». Prix 42px. Puis une carte « Packs de crédits » avec 5 pastilles. Note de paiement centrée.
10. **FAQ** — 9 items en accordéon (un seul ouvert à la fois, le premier ouvert par défaut). Item ouvert : fond `linear-gradient(160deg, rgba(129,140,248,0.10), rgba(255,255,255,0.02))`, bordure `rgba(129,140,248,0.4)`, icône `+` tournée à 45°. Puis carte CTA « Encore une question ? » à bordure dégradée.
11. **Footer** — bandeau CTA final (H2 52px), puis 4 colonnes (marque + Produit / Ressources / Légal), puis barre basse (© 2026 · Conçu en France 🇫🇷).

**Fond global** : 3 halos radiaux fixes animés en `sfAurora` (violet en haut au centre, cyan à gauche, rose en bas à droite), `filter: blur(110–120px)`, `position: fixed; inset: 0; z-index: 0; pointer-events: none`. Le contenu est en `z-index: 1`.

### État nécessaire (landing)

- `openFaq: number | null` — index de la question ouverte (0 par défaut).
- Compteurs : `IntersectionObserver` à `threshold: 0.3`, démarre une fois, `requestAnimationFrame`.
- Reveals au scroll : `IntersectionObserver` `threshold: 0.12`, `rootMargin: '0px 0px -40px 0px'`, ajoute opacité 1 + `translateY(0)` avec `transition: opacity .7s ease, transform .7s cubic-bezier(0.2,0.7,0.2,1)`. Les éléments déjà visibles au chargement ne sont pas animés.

---

# PARTIE 2 — Application (`electron-app/`)

Fichier de référence : `ScaleFlow App Redesign.dc.html`.

## Shell / Sidebar

Largeur `232px`, fond `rgba(8,8,20,0.85)`, `backdrop-filter: blur(16px)`, bordure droite `rgba(255,255,255,0.07)`.

- **En-tête** : logo (tuile 30px dégradé + « ScaleFlow ») + badge de plan (`PRO`) aligné à droite.
- **Recherche** : bouton pleine largeur, hauteur 34px, `border-radius:10px`, texte « Rechercher… » + raccourci `Ctrl K` dans un badge. Déclenche la command palette existante.
- **Accueil** épinglé en haut, hors groupe.
- **Groupes** (identiques à `NAV_SECTIONS` dans `Layout.tsx`) :
  - *Principal* : Téléphones, Banque, Bibliothèque, Activité
  - *Publier* : Publication, Automatisation, Warmup Compte
  - *Studio vidéo* : Studio vidéo
  - *Cloud* (super-admin) : Cloud Phones, Proxies, Automatisation
- **Item actif** : fond `linear-gradient(135deg, rgba(139,92,246,0.22), rgba(34,211,238,0.10))`, bordure `rgba(139,92,246,0.35)`, texte `#E9D5FF`, weight 800. Inactif : transparent, texte `rgba(196,181,253,0.65)`, weight 600.
- **Pied** : carte de crédits (solde en dégradé, jauge, bouton « + Recharger ») puis ligne utilisateur (avatar dégradé, nom, « Organisation · Owner », roue crantée).

⚠️ Ne pas modifier la logique de permissions existante (`isVisibleTab`, `PAGE_PERM_KEY`, `canSeeTab`) — seul l'habillage change.

## Écran : Accueil (Hub)

- En-tête : date avec point lumineux, « Bonjour, {prénom} » (prénom en dégradé), chip « En direct », bouton « ⟳ Actualiser ».
- 4 KPI en grille : Téléphones (+ sous-ligne verte « 48 en ligne »), Vidéos en banque, Posts · 7 jours (chiffre vert), Crédits (chiffre `#FBBF24`). Chaque carte a un fond dégradé teinté de son accent et remonte de 3px au survol.
- 4 actions rapides en pills (Mass Posting en primaire).
- Deux colonnes : « Posts à venir » et « Activité récente », lignes de 13px avec icône 34px, titre, méta, badge de statut.

## Écran : Téléphones

En-tête (titre + compteur 52 + sous-titre) · toggle « Auto » · bouton « ⇅ Sync GéeLark ».
4 KPI : Total, En ligne (vert), Hors ligne, À traiter (rouge).
Barre de filtres : recherche, dropdown « Tous les groupes », pills Tous / En ligne / Hors ligne.
Table `grid-template-columns: 44px 1.5fr 1fr 1fr 1fr 120px` — colonnes # · Téléphone (nom mono + compte) · Groupe (badge) · Statut (point + label) · GéeLark (IG OK / Bloqué + IP mono) · Actions (▶ ouvrir, ⋯ détails).
Statuts et couleurs : En ligne `#34D399` · Warmup `#FB923C` · Limité `#FCD34D` · Erreur `#F87171` · Hors ligne `rgba(148,163,184,0.6)`.
Survol de ligne : `background: rgba(139,92,246,0.05)`.

## Écran : Banque de contenu

En-tête + boutons « ⇅ Sync Drive » et « + Importer ».
Onglets de type : Vidéos · 347 / Images · 89 / Captions · 156. Recherche à droite.
Pills de dossiers (Motivation, Lifestyle, Produits, + Dossier).
Grille 6 colonnes de vignettes `aspect-ratio: 9/16`, fond en rayures diagonales teintées (placeholder de miniature), case de sélection en haut à droite, durée en haut à gauche, nom + méta en bas sur un dégradé sombre. Sélectionnée : bordure `2px #818CF8`.
**Barre d'actions sticky en bas** quand ≥1 élément sélectionné : compte, puis ✂ Remix / 📁 Déplacer / ⚡ Mass Posting.

## Écran : Publication (hub)

En-tête (eyebrow « Publication », H1 « Publie partout, en un clic. »), puis un fil des 3 étapes (Choisis un format → Comptes & contenu → Publie en 1 clic).
Grille 2×2 de cartes de format, chacune avec **un aperçu réaliste** :
- **Reels** — liste de 3 téléphones avec statuts + barre de progression 42/47. CTA « Ouvrir Reels → ».
- **Story** — maquette de story (barres de progression en haut, sticker blanc « 🔗 Voir plus » en bas) **+ liste des liens différents par compte** (`/brandparis`, `/studiocrea`, `/ugcfactory`) avec la mention « 1 lien unique par compte ».
- **Photo** — grille de feed 4×2 en dégradés décroissants, overlay « Bientôt », CTA désactivé « 🔒 Bientôt disponible ».
- **Cross-posting** (admin) — vidéo source → 6 pastilles de plateformes (Facebook, Shorts, X, Threads, Reddit, Pinterest).

## Écran : Reels (= `Publish.tsx` + `MassPosting.tsx`)

### Popup de choix de plateforme (bloquant, à l'entrée)

Reproduit le comportement de `Publish.tsx` : à l'ouverture, **modale centrée** `max-width:560px`, `border-radius:22px`, fond `linear-gradient(170deg, rgba(20,20,44,0.98), rgba(10,10,26,0.98))`, deux halos internes floutés, animation `sfUp .35s cubic-bezier(0.16,1,0.3,1)`.
Titre « Où veux-tu **publier ?** », sous-titre « Choisis la plateforme pour cette session de publication. »
3 cartes : Instagram (« Reels — publication native via RPA »), TikTok (« Vidéos — publication native GeeLark »), Threads (« Vidéos & photos — natif GeeLark », super-admin). La dernière plateforme utilisée porte un badge « Dernier choix » et une bordure `rgba(165,180,252,0.35)`.
Note de bas : « Tu pourras changer de plateforme à tout moment depuis le bandeau en haut. »
Persister le choix dans `localStorage` sous `sf-mp-platform` (comportement actuel).

### Wizard (après le choix)

Fil d'ariane « Publication / Reels », H1 « Publier un Reels », chip « 48 phones prêts ».
**Bandeau plateforme** : label, plateforme choisie en pill violette, description, bouton « Changer de plateforme » à droite (rouvre la modale).
**Stepper** 4 pastilles : ① Comptes · ② Vidéos · ③ Légende · ④ Lancement (cliquables).

- **Étape 1 — Comptes.** Phrase de guidage : « Étape 1 · Choisis les comptes qui vont publier — coche un ou plusieurs téléphones. » Puis **dropdown « Groupe GeeLark »** (menu déroulant listant tous les groupes avec leur compte : Tous les groupes, Groupe FR, Groupe US, Nouveaux, Clients ; coche sur l'actif) et le compteur « N sélectionnés · 2 crédits / téléphone ». Grille 4 colonnes de cartes de téléphone (nom mono, case à cocher, compte, statut + followers). La liste est filtrée par plateforme **et** par groupe.
- **Étape 2 — Vidéos.** Guidage « Étape 2 · … réparties sur les N comptes sélectionnés. » Sources en pills : 🗂 Banque / 📁 Dossier / 💻 Mon PC. Grille de vignettes 9:16 sélectionnables + case « + ». Pills de distribution : Séquentielle / Aléatoire / Usage unique ♻.
  **Bloc miniature de couverture** (à conserver — existe déjà dans l'app) : 3 frames candidates `54×92px` sélectionnables avec la durée, plus « ＋ Importer une miniature » et « ⤿ Extraire une frame ».
- **Étape 3 — Légende.** Deux colonnes : éditeur de légende commune (bouton « ✦ Générer par IA », zone de texte, pills « 💬 Depuis la Banque de captions » / « Variante par compte », compteur 124 / 2 200) et aperçu du post (avatar + handle, vignette, légende).
- **Étape 4 — Lancement.** Guidage « Étape 4 · Ajuste le comportement du run… ». Carte de réglages en 3 colonnes : **Téléphones simultanés** (Tous / 10 / 5), **Essai Reels** (toggle, off), **Usage unique des vidéos** (toggle, on) — chacun avec une ligne d'explication. Puis deux colonnes : récapitulatif (Comptes, Vidéos, Miniature `frame 0:0N`, Plateforme, Groupe, Téléphones simultanés, **Coût = N × 2 crédits**) + bouton « ⚡ Lancer la diffusion », et panneau « Progression en direct » (barre + lignes par téléphone qui passent en file → en cours (point pulsant) → publié).
  Mention sous le bouton : « Reprise automatique en cas de refresh · fenêtre 24 h ».

## Écran : Story (`StoryLink.tsx`)

Fil « Publication / Story », H1 « Publier une Story », sous-titre « Une image + un sticker lien propre à chaque compte, publiée en masse. 1 crédit par téléphone. »
À droite : chip « 📸 Instagram uniquement » + note « Android 13 à 16 · cloud phone en anglais ».

Deux colonnes (`1.55fr / 1fr`, colonne droite `sticky top:20px`) :

**Colonne gauche — les 3 étapes réelles :**
1. *Images de la story* — pills Séquentiel / Aléatoire, grille 6 colonnes de vignettes 9:16 sélectionnables + case « ＋ ». Note : « Les images sont distribuées entre les comptes selon le mode choisi. »
2. *Pool de textes sticker* — champ + bouton « Ajouter », puis les textes en pills supprimables (« Voir plus », « Swipe up », « Mon lien 👆 »). Note : « Texte affiché sur le sticker lien… Plusieurs textes = distribués entre les comptes. Laisse vide pour n'afficher que l'URL. »
3. *Lien sticker par compte* — bouton « Appliquer à tous », puis une ligne par téléphone : case, nom mono, compte, champ de lien mono. Les comptes sans lien affichent « aucun lien défini » en rouge. Note : « Chaque compte publie SON propre lien. Il est sauvegardé automatiquement et réutilisé par les tâches automatiques. »

**Colonne droite :** aperçu de story `150×266px` (barres de progression, avatar + handle, sticker blanc avec le premier texte du pool) ; puis récapitulatif (Comptes, Images, Textes sticker, **Coût = 1 crédit / téléphone**), bouton primaire « 🔗 Publier la story » et bouton secondaire « Test gratuit — sans publier » avec l'explication « Le test déroule toute l'automation (image, caméra, sticker, lien) et s'arrête avant de publier. »

## Écran : Studio vidéo (hub)

Eyebrow « Studio Vidéo », H1 « Ton usine à **contenu unique.** », fil « 1 vidéo source → 4 outils → ∞ variantes uniques → 1 clic export ».
Grille 2×2 des 4 outils, chacun avec un aperçu :
- **Remix** (Uniqueness) — source → 3 variantes → « ×24 uniques ».
- **Spoof** (Anti-détection) — lignes mono Device / GPS / EXIF avec des ✓.
- **Sous-titres** (IA Whisper) — mots « tu vas **ADORER** ça », le mot fort sur fond `#A5B4FC`, mention « Whisper · live ».
- **Mixer** (Overlay) — bloc « HOOK » sur fond sombre, mention « texte sur vidéo ».

## Écrans : les 4 outils du studio

Même gabarit pour les quatre : fil « Studio vidéo / {Outil} », H1 avec emoji, description reprise du hub, chip « Gratuit · 0 crédit ».
Deux colonnes (`1.35fr / 1fr`, droite sticky) :

- **Colonne gauche** : carte « 1 · Vidéos sources » (pills 🗂 Banque / 💻 Mon PC + grille 6 colonnes de vignettes sélectionnables) puis carte « 2 · {réglages} » spécifique :
  - **Remix** — 5 sliders (Luminosité ±6 %, Contraste ±4 %, Zoom ±3 %, Vitesse 0,95–1,05×, Recadrage ±2 %) puis « Variantes par vidéo » ×6 / ×12 / ×24 / ×48.
  - **Spoof** — 5 lignes à toggle : Device (`iPhone 15 Pro`), GPS (`34.05, -118.2`), EXIF (`nettoyé`), Empreinte fichier (`unique`), Piste audio (`±1 %`), chacune avec sa ligne d'explication. Off ⇒ valeur `—`.
  - **Sous-titres** — Langue (Auto / FR / EN), Position (Haut / Centre / Bas), puis « Style du mot mis en avant » : Fond plein / Contour / Néon, chaque option affichant un échantillon « ADORER ».
  - **Mixer** — « Hook à incruster » : 4 propositions en pills (« POV : tu découvres ça », « Personne n'en parle », « Arrête de scroller », « Le secret est simple ») + « ＋ Texte perso » ; puis Position (Haut / Centre), Fond (Noir / Aucun), Rendu (Serveur, en vert).
- **Colonne droite** : aperçu `150×266px` qui reflète l'outil (variantes empilées + « ×24 » / checklist de métadonnées / sous-titres mot par mot / bloc HOOK), puis récapitulatif (Vidéos sources, Sortie, Coût = Gratuit), bouton primaire propre à l'outil et bouton « Envoyer vers la banque ».

## Écran : Bibliothèque (`Library.tsx`)

H1 « Lance une tâche sur tes téléphones » avec icône verte, sous-titre « Sélectionne des téléphones, choisis une action — elle s'exécute sur chacun, suivi en direct. », chip « N sélectionnés », bouton « ↻ Rafraîchir ».
Deux colonnes (`330px / 1fr`, gauche sticky) :
- **Gauche** : carte « Téléphones (8) » avec boutons Tout / Aucun, recherche + dropdown de groupe, puis la liste (case, point de statut, nom mono, marqueur de job ✓).
- **Droite** : bandeau d'invite si aucune sélection, label « Actions disponibles », puis **grille 3 colonnes des 10 actions réelles** — Allumer, Éteindre, Redémarrer, Envoyer des médias, Warmup Instagram, Warmup TikTok, Éditer profil IG, Instagram en anglais, Vérifier l'IP, Commande ADB (bordure rouge, super-admin). Chaque carte : icône 40px sur son dégradé, titre, description, CTA « Lancer sur N tél. → ». Désactivées (opacité 0.5) sans sélection.
  Puis carte de suivi : chip Terminé / En cours, compteur `✓ n · ✕ n · N total`, et console de logs monospace 11px sur fond `rgba(0,0,0,0.35)`.

## Écran : Activité (`Activity.tsx`)

Deux sous-onglets en barre soulignée (`border-bottom: 2px solid #818CF8` sur l'actif) : **🕑 Journal** et **📊 Comptes & Stats**.
- *Journal* — titre « Historique », filtres Tout / Réussis / Échecs / En cours, puis liste : icône ✓/! colorée, titre du run, méta (plateforme · N téléphones · auteur), score `x/y` en Space Grotesk, badge de statut, date à droite.
- *Comptes & Stats* — 4 KPI (Vues totales, Abonnés, Vues moyennes, Pic de vues en vert) puis table Compte (avatar dégradé + handle) · Abonnés · Vues 7j · Posts · État (Actif / Warmup / Limité / Bloqué avec point coloré).

## Écran : Automatisation (`Automation.tsx`)

Deux sous-onglets : **📅 Programmé** (Scheduler) et **🤖 Récurrent** (Tasks, super-admin).
- *Programmé* — H1 « Posts programmés », note « Exécutés côté serveur — ton PC peut être éteint. », bouton « ＋ Programmer un post ». Deux colonnes : file d'attente (icône, titre, méta, heure, badge programmé/publié/échec) et calendrier du mois (31 cellules, `rgba(129,140,248,…)` = programmé, `rgba(52,211,153,…)` = publié, légende dessous).
- *Récurrent* — H1 « Tâches récurrentes », note reprenant la règle métier réelle : « 50 crédits/jour par tâche active, plus 2 crédits par téléphone à chaque exécution. » Bouton « ＋ Nouvelle tâche ». Puis une carte par tâche : toggle actif/pause (vert), titre + méta (N téléphones · fréquence), badge active/en pause, sous-étapes en pills (`① Warmup 30 min`, `② Vérifier IP`…), et pied avec « Prochaine : … » + « Crédits/jour : … » en `#FBBF24`.

## Écran : Warmup Compte (`Warmup.tsx`)

H1 « Instagram Automation », sous-titre mono en majuscules `CYBER MONITORING DASHBOARD` (couleur `rgba(52,211,153,0.75)`, `letter-spacing: 0.22em`), chip « 48 en ligne · N sélectionnés ».
**3 onglets** en boutons mono (`LOG IN` / `MASS EDIT` / `WARMUP`), actif = fond dégradé violet + bordure `rgba(139,92,246,0.5)`.
Deux colonnes (`300px / 1fr`, gauche sticky) :
- **Gauche — « GéeLark Phones »** (partagée par les 3 onglets) : bouton « Tout sélectionner », recherche, liste scrollable (case, nom mono, compte, point de statut).
- **Droite, selon l'onglet** :
  - **LOG IN** — « Identifiants Instagram », « N téléphones · un identifiant par appareil », puis **un tableau avec une ligne par téléphone sélectionné** : colonnes Téléphone / Identifiant ou email / Mot de passe / Secret TOTP. Sous le tableau : « 📋 Coller depuis un CSV » et « Même mot de passe partout ». Encart d'avertissement ambre : « Le téléphone démarre et saisit les identifiants automatiquement. Si la 2FA est activée, fournis le secret TOTP. » Bouton mono `LANCER LA CONNEXION`.
  - **MASS EDIT** — « Modifications de profil », « Appliquées à tous les téléphones sélectionnés (N) », champs Nom du profil / Nom d'utilisateur / Bio / Photo de profil (URL directe, téléchargée via curl), note « Instagram peut refuser si le nom d'utilisateur est déjà pris. », puis **section « Téléphones concernés »** listant les appareils en pills. Bouton `APPLIQUER AUX N COMPTES`.
  - **WARMUP** — **modèle par durée de session, pas par cadence horaire.** « Durée de la session » avec 4 cartes : 15 min (échauffement) / 30 min (recommandé) / 1 h (session longue) / 2 h (compte mûr). Encart ambre : « Session de {durée} sur N téléphones — les appareils s'éteignent à la fin, pas besoin de les laisser tourner en continu. » Puis « Actions pendant la session » : 3 toggles (♥ Liker des posts, ▶ Regarder des Reels, ＋ Suivre les suggestions) affichant chacun **le total estimé sur la durée** (`≈ 4 au total` pour 8/h sur 30 min → `Math.round(rate × durée/60)`), pas de barre de progression. Enfin une carte avec seulement « Téléphones simultanés » (5 / 10 / Tous) + explication, et le bouton orange `🔥 LANCER LE WARMUP · {durée} · N COMPTES`.
    ⚠️ **Pas de planification / répétition** dans cet onglet.

## Écran : Cloud Phones (`CloudPhones.tsx`)

C'est l'écran stratégique — le plus soigné.

- En-tête : deux badges (« Infrastructure », « Auto-hébergé »), H1 34px « Cloud Phones », sous-titre « Tes propres appareils Android, sur ton serveur. Plus de dépendance à GeeLark, plus de limite de comptes. », boutons « ⚙ Agent » et « ＋ Créer un appareil ».
- **Bandeau de statut de l'agent** : fond `linear-gradient(120deg, rgba(52,211,153,0.08), rgba(255,255,255,0.015))`, bordure `rgba(52,211,153,0.28)`. Icône 🖥, « Agent connecté » + URL et version en mono, puis à droite trois métriques (CPU 34 %, RAM 11,2 / 32 Go, Latence 18 ms en vert).
- **Panneau de config dépliable** (bouton ⚙ Agent) : « Configurer l'agent », note « L'URL et le token de ton agent auto-hébergé — affichés à la fin de l'installation. », champs URL de l'agent / Token + bouton « Tester ».
- **4 KPI** : Appareils (16), Démarrés (11, vert), Arrêtés (5), Sessions ADB (7, cyan).
  ⚠️ Ne pas afficher de coût mensuel ni de comparaison de prix.
- **Barre de filtres** : recherche (« Rechercher un appareil, un compte, un proxy… ») + pills Tous · 16 / Démarrés · 11 / Arrêtés · 5.
- **Table** `grid-template-columns: 40px 1.25fr 1fr 0.9fr 1fr 0.85fr 120px` :
  - case de sélection (en-tête = tout cocher, état indéterminé affiché `–`)
  - Appareil : nom mono `sf-cloud-01` + compte lié
  - Modèle : `Pixel 7` + `Android 14` en mono
  - Groupe : badge
  - Proxy · IP : nom du proxy + IP sortante mono (`—` grisé si arrêté)
  - Statut : démarré (vert) / démarrage (ambre, point pulsant) / arrêté (gris)
  - Actions : bouton contextuel **Démarrer** (vert) ou **Arrêter**, et 🖥 pour l'écran distant
  - Ligne sélectionnée : fond `rgba(99,102,241,0.07)`
- **Barre d'actions groupées** (sticky en bas, apparaît dès 1 sélection) : « N appareil(s) sélectionné(s) » puis 🔌 Démarrer (vert) · ⏻ Arrêter · 🌐 Assigner un proxy · 📁 Changer de groupe.

## Écran : Proxies (`Proxies.tsx`)

En-tête avec icône cyan, H1 « Proxies », sous-titre « SOCKS5 recommandé. Crée des groupes, teste les IP, puis assigne-les aux téléphones. », boutons « 🔎 Vérifier », « ＋ Nouveau groupe », « ＋ Ajouter des proxies ».
4 KPI : Total (24), OK (21, vert), KO (2, rouge), Latence moy. (148 ms).
Chips de groupes : Tous · 24 / FR · 12 / US · 9 / Sans groupe · 3 (actif en cyan).
Table `44px 140px 1.6fr 130px 1fr 120px 40px` — # · Groupe (badge) · Proxy (pill mono copiable avec ⧉) · Statut (OK vert + latence / KO rouge / non testé gris) · IP sortante mono · Tels (libre gris / ● nom en vert / partagé ×N en ambre) · ✕ supprimer.

## Écran : Automatisation UI / Flows (`AutomationLab.tsx`)

En-tête avec icône violette, H1 « Automatisation », sous-titre « Catalogue de flux RPA à exécuter sur tes cloud phones. Filtre par plateforme. », bouton « ＋ Créer un flux ».
Filtres : 🌐 Tous / 📸 Instagram / 🎵 TikTok / 🧵 Threads / ⚙️ Système.
Grille 3 colonnes de cartes de flux : icône 38px sur son dégradé, badge Vérifié (vert) ou Beta (ambre), titre, description, pied avec plateforme · N étapes et CTA « Exécuter → » / « Tester → ».
Flux : Publier un Reel (12 étapes), Story + sticker lien (18), Publier sur TikTok (10), Warmup feed (8), Éditer le profil (14), Publier sur Threads (9, Beta).

---

## Interactions & comportements transverses

- **Navigation** : un seul état de page dans le shell ; les hubs (Publication, Studio vidéo) naviguent vers leurs sous-écrans ; les sous-écrans ont un fil d'ariane cliquable qui revient au hub.
- **Sélections** : toujours multiples, avec case visible, ligne/carte teintée, et compteur dans l'en-tête ou une barre sticky d'actions groupées.
- **Toggles** : piste `36×20px`, `border-radius:99px`, pastille `16px`, `transition: background .25s ease`. On : piste teintée de l'accent, pastille claire. Off : piste `rgba(255,255,255,0.1)`, pastille `rgba(196,181,253,0.5)`.
- **Pills de filtre** : actif = fond `rgba(<accent>,0.16)` + bordure `rgba(<accent>,0.4)` + texte clair + weight 800 ; inactif = bordure `rgba(255,255,255,0.12)` + texte `rgba(196,181,253,0.6)`.
- **États vides** : icône, titre, phrase d'explication, bouton d'action — utiliser `sf-empty` existant.
- **Chargement** : squelettes de même géométrie que les lignes réelles (`sf-skeleton`).
- **Survol de ligne de table** : `rgba(139,92,246,0.05)`.

## State management (app)

Un état par écran, tous locaux :

| Écran | État |
|---|---|
| Shell | `page: Page` (identique à l'union `Page` existante) |
| Reels | `platform`, `platformChosen`, `lastPlatform` (persisté `sf-mp-platform`), `step: 1..4`, `selectedPhones: number[]`, `group: string`, `groupsOpen: boolean`, `cover: number`, `running`, `progress` |
| Story | `images: number[]`, `stickerTexts: string[]`, `selectedPhones: number[]`, `linksByPhone: Record<id,string>` |
| Outils studio | `sources: number[]`, `remixCount`, `spoofToggles: string[]`, `subStyle`, `hook` |
| Bibliothèque | `selectedPhones: number[]`, `jobs: Record<id,status>`, `logs: string[]` |
| Activité | `tab: 'journal' \| 'accounts'` |
| Automatisation | `tab: 'scheduled' \| 'recurring'`, `pausedTasks: number[]` |
| Warmup | `tab: 'login' \| 'massEdit' \| 'warmup'`, `selectedPhones`, `actions: string[]`, `durationMin: 15\|30\|60\|120` |
| Cloud Phones | `filter: 'all'\|'on'\|'off'`, `selected: number[]`, `agentPanelOpen: boolean` |
| Proxies | `group: string` |
| Flows | `platformFilter: string` |

Le reste (données réelles, crédits, permissions, runs) vient des hooks et stores existants — `useCredits`, `useOrg`, `useLicense`, `massPostingStore`, `activeRuns`, `schedulerService`, `geelark`. **Ne rien réimplémenter côté données.**

## Assets

Aucun asset nouveau. Les vignettes de vidéos/images sont des **placeholders en rayures diagonales CSS** :

```css
background: repeating-linear-gradient(45deg,
  rgba(129,140,248,0.12), rgba(129,140,248,0.12) 7px,
  rgba(129,140,248,0.04) 7px, rgba(129,140,248,0.04) 14px);
```

À remplacer par les vraies miniatures (`content_bank`) à l'intégration. Le logo reste `SFLogo` de `Layout.tsx` ; les emojis d'onglets sont ceux déjà en place.

## Files

| Fichier | Contenu |
|---|---|
| `ScaleFlow Redesign v2.dc.html` | Landing page complète (partie 1) |
| `ScaleFlow App Redesign.dc.html` | Shell + tous les écrans de l'app (partie 2) |
| `support.js` | Runtime du prototype — **référence uniquement, ne pas porter** |

Pour ouvrir les prototypes : servir le dossier (`npx serve .`) et ouvrir les fichiers `.dc.html` dans un navigateur.

## Ordre d'intégration suggéré

1. Landing (`website/`) — indépendante, aucun risque de régression.
2. Shell / sidebar (`Layout.tsx`) — habillage seul, permissions inchangées.
3. Hub, Téléphones, Banque — écrans les plus vus.
4. Publication → Reels → Story.
5. Studio vidéo + ses 4 outils.
6. Bibliothèque, Activité, Automatisation.
7. Cloud Phones, Proxies, Flows.

## Repo source

- `repo: Typedlappleeee/ig-trackerv2`
- `branch: main`
- Commandes utiles (depuis `electron-app/`) : `npm run dev:web`, `npm run build:web` (le check rapide), `npm test`.
- Voir `CLAUDE.md` à la racine pour l'architecture desktop/web, GeeLark, crédits et permissions.
