# Comment donner ça à Claude Code

Ce dossier contient tout le redesign ScaleFlow fait avec Claude : la landing page en
code React prêt à copier, la spécification complète de l'application, et les prototypes
HTML de référence.

## En trois gestes

**1. Dépose ce dossier à la racine de ton repo**

```
ig-trackerv2/
├── _redesign/        ← ici
├── website/
├── electron-app/
└── CLAUDE.md
```

**2. Ignore-le dans git** — c'est de la matière de travail, pas du code de prod :

```bash
echo "_redesign/" >> .gitignore
```

**3. Ouvre Claude Code à la racine et envoie-lui exactement ça :**

> Lis `_redesign/README.md` en entier et applique le redesign décrit, en commençant par
> le chantier 1 (la landing dans `website/`). Suis les consignes de livraison à la fin
> du fichier : branche dédiée, build vert avant chaque commit, un commit par chantier,
> puis push. Ne merge pas sur `main`, donne-moi l'URL de preview Vercel.

C'est tout. Le reste est décrit dans le brief.

---

## Ce qu'il y a dedans

| Chemin | Rôle |
|---|---|
| `README.md` | **Le brief.** Tout ce que Claude Code doit faire, chantier par chantier, jusqu'au push |
| `integration/website/src/` | Code React de la landing, prêt à copier dans `website/src/` |
| `integration/tailwind-additions.js` | Keyframes à fusionner dans `website/tailwind.config.js` |
| `integration/ETAPES.md` | La même procédure, version manuelle si tu préfères la faire toi-même |
| `handoff/README.md` | Spécification détaillée de l'app : tokens exacts, chaque écran, interactions, état |
| `prototypes/landing.dc.html` | La landing telle qu'elle doit rendre — ouvre-la dans un navigateur |
| `prototypes/app.dc.html` | L'app telle qu'elle doit rendre — tous les écrans |
| `prototypes/support.js` | Nécessaire aux deux prototypes, garde-le à côté |

Pour voir les prototypes : `cd _redesign/prototypes && npx serve .`

---

## Les deux chantiers

**La landing (`website/`)** — c'est du copier-coller. Le code React existe, il ne reste
que deux ajustements de config (Manrope + keyframes Tailwind). Comptes ~15 minutes,
aucun risque de régression.

**L'app (`electron-app/`)** — c'est le gros morceau : shell + 14 écrans à recréer en TSX
à partir de la spécification. Claude Code doit avancer écran par écran, en réutilisant
les classes `sf-*` existantes et sans toucher aux permissions ni aux stores.

Si tu veux limiter le premier passage, dis-lui simplement de s'arrêter après la landing
et le shell, et de te montrer le résultat avant de continuer.

---

## Un conseil

Fais-lui faire la landing en premier et regarde la preview Vercel avant de le lancer sur
l'app. Ça valide le logo, les polices et la direction visuelle sur quelque chose de petit
et sans risque, avant d'engager les 14 écrans.
