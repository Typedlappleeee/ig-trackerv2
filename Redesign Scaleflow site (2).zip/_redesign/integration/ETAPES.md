# Déployer le redesign — étape par étape

Tu fais tout depuis ta machine. Je ne peux ni commit ni push : je te livre les
fichiers, tu les copies et tu pousses. Vercel redéploie tout seul.

---

## Étape 0 — Préparer le terrain (2 min)

```bash
cd ~/chemin/vers/ig-trackerv2
git checkout main
git pull
git checkout -b redesign-scaleflow
```

> La branche dédiée te permet de tout annuler d'un `git checkout main` si ça ne
> te plaît pas, sans toucher à la prod.

---

## Étape 1 — Copier les fichiers de la landing (3 min)

Dézippe le package, puis copie **le contenu** de `integration/website/src/`
dans `website/src/` de ton repo (écrase ce qui existe).

Fichiers concernés :

| Fichier | Statut |
|---|---|
| `App.tsx` | remplacé |
| `hooks/useScrollFx.ts` | nouveau |
| `lib/links.ts` | nouveau |
| `components/Intro.tsx` | nouveau |
| `components/Textures.tsx` | nouveau |
| `components/Aurora.tsx` | nouveau |
| `components/CloudPhones.tsx` | nouveau |
| `components/CreditsGrid.tsx` | nouveau |
| `components/StatCounter.tsx` | nouveau |
| `components/HowItWorks.tsx` | nouveau |
| `components/Logo.tsx` | remplacé |
| `components/Nav.tsx` | remplacé |
| `components/Hero.tsx` | remplacé |
| `components/AppMockup.tsx` | remplacé |
| `components/Marquee.tsx` | remplacé |
| `components/Features.tsx` | remplacé |
| `components/Testimonials.tsx` | remplacé |
| `components/Pricing.tsx` | remplacé |
| `components/Faq.tsx` | remplacé |
| `components/Footer.tsx` | remplacé |

`components/Icons.tsx` n'est **pas** touché.

---

## Étape 2 — Ajouter la police Manrope (1 min)

Dans `website/index.html`, remplace la ligne des Google Fonts par :

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
```

Puis dans `website/tailwind.config.js`, mets Manrope en police par défaut :

```js
fontFamily: {
  sans:    ['Manrope', 'Inter', 'system-ui', '-apple-system', 'sans-serif'],
  display: ['"Space Grotesk"', 'Manrope', 'system-ui', 'sans-serif'],
  mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
},
```

Et dans `website/src/index.css`, dans le bloc `body` :

```css
font-family: 'Manrope', system-ui, -apple-system, sans-serif;
```

---

## Étape 3 — Ajouter les animations Tailwind (2 min)

Ouvre `integration/tailwind-additions.js` et **fusionne** son contenu dans
`website/tailwind.config.js`, dans `theme.extend.animation` et
`theme.extend.keyframes`. Garde tout ce qui existe déjà, ajoute seulement les
entrées `sf*` qui manquent.

C'est ce qui fait marcher le rideau d'ouverture, le grain, les ondes de la
section Cloud Phones et les reflets sur les boutons.

---

## Étape 4 — Vérifier en local (3 min)

```bash
cd website
npm install          # si tu ne l'as pas déjà fait
npm run dev          # ouvre l'URL affichée
```

À contrôler :
- le rideau d'ouverture se fend en deux au chargement
- le hero publie en direct (les tuiles s'allument une par une)
- la section Cloud Phones : le téléphone grossit quand tu scrolles
- les tarifs et la grille de crédits s'affichent
- la FAQ s'ouvre au clic

Puis le build de prod, c'est lui qui compte :

```bash
npm run build
```

> S'il échoue sur un type, envoie-moi l'erreur, je corrige le fichier.

---

## Étape 5 — Commit et push (1 min)

```bash
cd ..
git add .
git commit -m "Redesign de la landing : hero live, section Cloud Phones, animations au scroll"
git push -u origin redesign-scaleflow
```

---

## Étape 6 — Prévisualiser sur Vercel (2 min)

Vercel crée automatiquement une **URL de preview** pour la branche. Tu la trouves :
- soit dans le commentaire que Vercel poste sur GitHub,
- soit dans ton dashboard Vercel → le projet → onglet *Deployments*.

Regarde la preview sur mobile aussi.

---

## Étape 7 — Mettre en production (1 min)

Si la preview te plaît :

```bash
git checkout main
git merge redesign-scaleflow
git push
```

Vercel déploie sur `scaleflow.company` dans la minute.

**Pour annuler** : dashboard Vercel → *Deployments* → le déploiement précédent →
*Promote to Production*. Retour en arrière immédiat.

---

## Et l'application (`electron-app/`) ?

Les 14 écrans redesignés existent comme prototypes, pas encore en TSX — c'est
beaucoup plus gros que la landing (Hub, Téléphones, Banque, Publication, Reels,
Story, Studio + 4 outils, Bibliothèque, Activité, Automatisation, Cloud Phones,
Proxies, Flows).

Deux options :

**A. Claude Code s'en charge.** Donne-lui le dossier
`design_handoff_scaleflow_redesign/` et dis-lui :

> Lis `design_handoff_scaleflow_redesign/README.md` et applique le redesign à
> `electron-app/`, en commençant par le shell (`src/components/Layout.tsx`) puis
> le Hub. Réutilise les classes `sf-*` existantes de `src/index.css`, ne touche
> pas à la logique de permissions ni aux stores.

Le README contient les tokens exacts, chaque écran en détail, les interactions et
l'état nécessaire.

**B. Je te les convertis en TSX**, écran par écran. Dis-moi par lesquels commencer.

---

## Ordre recommandé

1. La landing d'abord (aucun risque de régression, c'est du marketing).
2. Le shell de l'app + le Hub (le plus visible pour tes utilisateurs).
3. Publication → Reels → Story (le cœur du produit).
4. Le reste.
