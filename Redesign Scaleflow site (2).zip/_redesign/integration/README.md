# Intégration — fichiers React prêts à copier

Ces fichiers sont du **vrai code de production** pour le repo `Typedlappleeee/ig-trackerv2`,
pas des prototypes. Ils sont écrits avec la stack et les conventions déjà en place
(React + Vite + Tailwind, classes `glass-card`, `btn-primary`, `gradient-text`,
`section-label`, `reveal`, `marquee-mask`, `stat-value` de `website/src/index.css`,
et les couleurs/animations de `website/tailwind.config.js`).

## Landing page — `website/`

Copie le contenu de `integration/website/src/` dans `website/src/` :

```
website/src/App.tsx                      ← remplacé
website/src/hooks/useReveal.ts           ← nouveau
website/src/lib/links.ts                 ← nouveau
website/src/components/Aurora.tsx        ← nouveau
website/src/components/Logo.tsx          ← remplacé
website/src/components/Nav.tsx           ← remplacé
website/src/components/StatCounter.tsx   ← nouveau (extrait de Hero)
website/src/components/AppMockup.tsx     ← remplacé
website/src/components/Hero.tsx          ← remplacé
website/src/components/Marquee.tsx       ← remplacé
website/src/components/Features.tsx      ← remplacé
website/src/components/HowItWorks.tsx    ← nouveau (section #how, absente avant)
website/src/components/Testimonials.tsx  ← remplacé (témoignages au nom d'agences)
website/src/components/Pricing.tsx       ← remplacé
website/src/components/Faq.tsx           ← remplacé
website/src/components/Footer.tsx        ← remplacé
```

`website/src/components/Icons.tsx` est **réutilisé tel quel** — aucune modification.

### Deux ajouts à faire à la main

**1. `website/index.html`** — ajouter Manrope aux polices Google (Space Grotesk et Inter sont déjà là) :

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
```

**2. `website/tailwind.config.js`** — passer le corps de texte sur Manrope :

```js
fontFamily: {
  sans:    ['Manrope', 'Inter', 'system-ui', '-apple-system', 'sans-serif'],
  display: ['"Space Grotesk"', 'Manrope', 'system-ui', 'sans-serif'],
  mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
},
```

Puis dans `website/src/index.css`, remplacer `font-family: 'Inter', …` par `font-family: 'Manrope', …` dans le bloc `body`.

### Vérifier

```bash
cd website
npm run dev     # contrôle visuel
npm run build   # doit passer sans erreur TS
```

## Ce qui a changé par rapport à la version actuelle

- **Hero** : titre 76px avec dégradés animés distincts sur « 100+ comptes » (cyan) et « un seul clic » (indigo→rose) ; stats et mockup remontés dans le flux.
- **AppMockup** : refait — fenêtre macOS, sidebar avec item actif et jauge de crédits, stepper, 4 lignes de téléphones avec statuts, CTA de diffusion.
- **Features** : 8 cartes, chacune avec un mini-aperçu illustratif ; les 3 cartes larges sont teintées de leur accent.
- **HowItWorks** : section `#how` qui manquait (le lien de nav pointait dans le vide).
- **Testimonials** : au nom d'agences (Agence GrowthPulse / UGC Lab / ScaleUp Media), gros chiffre en dégradé, avatar à initiales.
- **Pricing** : plan Pro en bordure dégradée sur fond `#0A0A1C` au lieu de `gradient-ring` + halo.
- **Faq** : item ouvert teinté indigo, icône `+` qui pivote à 45°.
- **Footer** : bandeau CTA 52px puis 5 colonnes.
- **Aurora** : halos extraits dans un composant dédié, `position: fixed`, `z-index: 0`.

## App Electron — `electron-app/`

Pas encore porté en TSX. Le design complet (shell + 14 écrans) est spécifié en détail
dans `design_handoff_scaleflow_redesign/README.md`, avec tokens exacts, layouts,
interactions et état nécessaire pour chaque écran.
