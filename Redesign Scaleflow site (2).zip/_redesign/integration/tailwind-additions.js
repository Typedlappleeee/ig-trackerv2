// À FUSIONNER dans website/tailwind.config.js → theme.extend
// (garde tout ce qui existe déjà, ajoute seulement ce qui manque)

animation: {
  // … tes animations existantes …
  'sf-curtain-l':  'sfCurtainL 2.2s cubic-bezier(0.76,0,0.24,1) forwards',
  'sf-curtain-r':  'sfCurtainR 2.2s cubic-bezier(0.76,0,0.24,1) forwards',
  'sf-intro-mark': 'sfIntroMark 2.2s ease forwards',
  'sf-intro-off':  'sfIntroOff 2.3s linear forwards',
  'sf-spin':       'sfSpin 1s linear infinite',
  'sf-grain':      'sfGrain 1.1s steps(4) infinite',
  'sf-sweep':      'sfSweep 3.4s ease-in-out infinite',
  'sf-scan':       'sfScan 4.5s linear infinite',
  'sf-glow':       'sfGlow 6s ease-in-out infinite',
  'sf-beam':       'sfBeam 5s ease-in-out infinite',
  'sf-ring':       'sfRing 4s ease-out infinite',
  'sf-rise':       'sfRise 1.1s cubic-bezier(0.16,1,0.3,1) both',
},

keyframes: {
  // … tes keyframes existantes …
  sfCurtainL:  { '0%,40%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(-101%)' } },
  sfCurtainR:  { '0%,40%': { transform: 'translateX(0)' }, '100%': { transform: 'translateX(101%)' } },
  sfIntroMark: { '0%': { opacity: '0', transform: 'scale(.82)' }, '16%,32%': { opacity: '1', transform: 'scale(1)' }, '46%,100%': { opacity: '0', transform: 'scale(1.1)' } },
  sfIntroOff:  { '0%,99%': { visibility: 'visible' }, '100%': { visibility: 'hidden' } },
  sfSpin:      { to: { transform: 'rotate(360deg)' } },
  sfGrain:     { '0%,100%': { transform: 'translate(0,0)' }, '20%': { transform: 'translate(-2%,1%)' }, '40%': { transform: 'translate(1%,-2%)' }, '60%': { transform: 'translate(-1%,2%)' }, '80%': { transform: 'translate(2%,-1%)' } },
  sfSweep:     { '0%': { transform: 'translateX(-130%)' }, '100%': { transform: 'translateX(340%)' } },
  sfScan:      { '0%': { transform: 'translateY(-100%)' }, '100%': { transform: 'translateY(1500%)' } },
  sfGlow:      { '0%,100%': { opacity: '.35' }, '50%': { opacity: '.8' } },
  sfBeam:      { '0%,100%': { opacity: '.15' }, '50%': { opacity: '.5' } },
  sfRing:      { '0%': { transform: 'scale(.7)', opacity: '.55' }, '100%': { transform: 'scale(2.1)', opacity: '0' } },
  sfRise:      { from: { opacity: '0', transform: 'translateY(115%) rotate(2.5deg)' }, to: { opacity: '1', transform: 'translateY(0) rotate(0)' } },
},
