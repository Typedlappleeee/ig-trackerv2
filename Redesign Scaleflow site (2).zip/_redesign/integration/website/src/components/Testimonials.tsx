import { useReveal } from '../hooks/useReveal'

/** Avis clients, repris mot pour mot des retours Telegram. */
const TESTIMONIALS = [
  {
    name: 'Francis', initials: 'F', date: '19 juin',
    avatar: 'linear-gradient(135deg,#22D3EE,#818CF8)',
    glow: 'rgba(34,211,238,0.3)',
    quote: "Très bon CRM, ça fait déjà plus d'un mois qu'on travaille avec Scaleflow et franchement c'est vraiment bien rien à dire. On a réduit notre staff de 90 % et en prime Quentin est au top 🤝 très bon service je recommande",
  },
  {
    name: 'France Killian', initials: 'FK', date: '19 juin',
    avatar: 'linear-gradient(135deg,#A855F7,#EC4899)',
    glow: 'rgba(168,85,247,0.35)',
    quote: "ScaleFlow nous a vraiment changé la vie. On a augmenté le nombre de nos comptes de 300 % tout en réduisant notre staff de plus de la moitié. Quentin est à l'écoute de toutes les propositions concernant l'application et très réactif. Je recommande a fond",
  },
  {
    name: 'Leon', initials: 'L', date: '20 juin',
    avatar: 'linear-gradient(135deg,#818CF8,#34D399)',
    glow: 'rgba(52,211,153,0.3)',
    quote: "Un logiciel performant, intuitif et véritablement utile au quotidien. Quentin se montre toujours disponible, à l'écoute des retours et très réactif lorsqu'il s'agit d'apporter des améliorations ou des correctifs. Un excellent service et un accompagnement irréprochable. Je recommande sans hésiter !",
  },
  {
    name: 'Njmoss', initials: 'N', date: '6 juillet',
    avatar: 'linear-gradient(135deg,#F59E0B,#EC4899)',
    glow: 'rgba(245,158,11,0.28)',
    quote: "Le logiciel est propre, il permet de faire beaucoup de chose en automatisé, un gain de temps et de performance.",
  },
]

export function Testimonials() {
  const ref = useReveal<HTMLElement>()

  return (
    <section
      id="testimonials"
      className="relative z-[1] px-6 py-25"
      style={{
        background: 'rgba(124,58,237,0.04)',
        borderTop: '1px solid rgba(139,92,246,0.18)',
        borderBottom: '1px solid rgba(139,92,246,0.18)',
      }}
      ref={ref}
    >
      <div className="mx-auto max-w-[1140px]">
        <div className="reveal mx-auto max-w-[640px] text-center">
          <span className="section-label">Social proof</span>
          <h2 className="font-display text-[2rem] font-bold leading-[1.1] tracking-[-0.02em] text-text sm:text-[46px]">
            Ils font tourner <span className="gradient-text-warm">ScaleFlow.</span>
          </h2>
          <p className="mt-4.5 text-base leading-relaxed text-text2">
            Les retours de nos clients, tels qu'ils nous les ont écrits.
          </p>
        </div>

        <div data-stagger className="mt-14 grid grid-cols-1 gap-4 md:grid-cols-2">
          {TESTIMONIALS.map(t => (
            <figure
              key={t.name}
              data-reveal
              className="reveal m-0 flex flex-col gap-4.5 rounded-[20px] border border-white/[0.09] bg-white/[0.03] p-7 transition-transform duration-300"
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = `0 24px 60px -20px ${t.glow}`
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = ''
                e.currentTarget.style.boxShadow = ''
              }}
            >
              <div className="flex items-center justify-between gap-2.5">
                <span className="tracking-[2px] text-[13px] text-[#FBBF24]">★★★★★</span>
                <span className="text-[11.5px] font-bold text-muted">{t.date}</span>
              </div>

              <blockquote className="m-0 flex-1 text-[14.5px] leading-[1.75] text-[rgba(226,222,255,0.88)]">
                {t.quote}
              </blockquote>

              <figcaption className="flex items-center gap-3 border-t border-white/[0.07] pt-4">
                <span
                  className="flex h-[38px] w-[38px] shrink-0 items-center justify-center rounded-full text-sm font-extrabold text-white"
                  style={{ background: t.avatar }}
                  aria-hidden="true"
                >
                  {t.initials}
                </span>
                <span className="flex min-w-0 flex-col gap-0.5">
                  <span className="truncate text-[13.5px] font-extrabold text-text">{t.name}</span>
                  <span className="truncate text-[11.5px] font-semibold text-muted">Client ScaleFlow</span>
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </div>
    </section>
  )
}
