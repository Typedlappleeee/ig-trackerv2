# Brief pour Claude Code — Redesign ScaleFlow

Tu travailles sur `Typedlappleeee/ig-trackerv2` (branche `main`). Ta mission : appliquer
le redesign complet décrit ci-dessous. Deux chantiers indépendants : la **landing page**
(`website/`) et l'**application** (`electron-app/`).

Lis d'abord `CLAUDE.md` à la racine pour l'architecture (split desktop/web, GeeLark,
crédits, permissions). Ne touche ni à la logique de permissions, ni aux stores, ni aux
appels API — le redesign est purement visuel et structurel côté UI.

---

## Ce dont tu disposes

| Dossier | Contenu |
|---|---|
| `_redesign/integration/website/src/` | **Code React prêt à copier** pour la landing (Tailwind, tes classes existantes) |
| `_redesign/integration/tailwind-additions.js` | Keyframes à fusionner dans `website/tailwind.config.js` |
| `_redesign/integration/ETAPES.md` | Procédure de déploiement pas à pas |
| `_redesign/handoff/README.md` | **Spécification complète de l'app** : tokens exacts, chaque écran, interactions, état |
| `_redesign/prototypes/*.dc.html` | Les prototypes HTML de référence (ouvre-les dans un navigateur pour voir le rendu voulu) |

⚠️ Les `.dc.html` sont des **références visuelles**, pas du code à copier. Recrée les
designs avec la stack du repo.

---

# CHANTIER 1 — Landing page (`website/`)

Le code React existe déjà dans `integration/website/src/`. C'est du copier-coller
plus deux ajustements de config.

## 1.1 Copier les fichiers

Copie le contenu de `_redesign/integration/website/src/` dans `website/src/` :

- **Remplacés** : `App.tsx`, `components/{Logo,Nav,Hero,AppMockup,Marquee,Features,Testimonials,Pricing,Faq,Footer}.tsx`
- **Nouveaux** : `hooks/{useReveal.ts,useScrollFx.ts}`, `lib/links.ts`, `components/{Intro,Textures,Aurora,StatCounter,HowItWorks,CloudPhones,CreditsGrid}.tsx`
- **Intact** : `components/Icons.tsx` — ne le modifie pas

## 1.2 Ajouter Manrope

Dans `website/index.html`, la ligne Google Fonts devient :

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
```

Dans `website/tailwind.config.js` :

```js
fontFamily: {
  sans:    ['Manrope', 'Inter', 'system-ui', '-apple-system', 'sans-serif'],
  display: ['"Space Grotesk"', 'Manrope', 'system-ui', 'sans-serif'],
  mono:    ['JetBrains Mono', 'Fira Code', 'monospace'],
},
```

Dans `website/src/index.css`, bloc `body` : `font-family: 'Manrope', system-ui, -apple-system, sans-serif;`

## 1.3 Fusionner les keyframes

Ajoute le contenu de `_redesign/integration/tailwind-additions.js` dans
`theme.extend.animation` et `theme.extend.keyframes` de `website/tailwind.config.js`.
**Garde tout l'existant**, ajoute seulement les entrées `sf*` manquantes.

## 1.4 Ce que contient la nouvelle landing

Dans l'ordre : intro animée (rideau qui se fend + logo) → nav sticky avec barre de
progression de scroll et lien « Cloud Phones · SOON » → hero avec **simulation de mass
posting en direct** (52 tuiles qui s'allument en séquence, compteur, ETA, log qui défile)
→ marquee → showcase de l'app en 4 onglets **dessinés en CSS** (pas de captures) →
**section Cloud Phones** → 8 features → 3 étapes → témoignages (noms d'agences, étoiles,
sans @) → tarifs + packs + **grille de consommation des crédits** → FAQ → CTA + footer.

Par-dessus tout : grain animé + scanlines très fines, et trois halos radiaux fixes.

### Animations au scroll

Pilotées par `useScrollFx()`, via des attributs sur les éléments :

| Attribut | Effet |
|---|---|
| `data-reveal` | entrée en `rotateX(9deg)` + flou 7px qui se dissipe (1s) |
| `data-stagger` | sur un conteneur : cascade de 75 ms entre ses enfants `[data-reveal]` |
| `data-fadeout` | s'efface, descend et rétrécit au scroll (mockup du hero) |
| `data-zoom` | grossit de 84 % à 100 % selon l'entrée dans le viewport (téléphone Cloud) |
| `data-rotate` | se redresse de 16° à 0° (maquette du showcase) |
| `data-count="1284"` + `data-suffix` | compteur qui monte au reveal |

Un seul `requestAnimationFrame` écrit les transforms directement — pas de re-render React.
`prefers-reduced-motion` est respecté.

### Section Cloud Phones (`CloudPhones.tsx`)

C'est la pièce marketing la plus importante. Fond quasi-noir, grille cyan en masque
radial, **trois ondes concentriques** qui se propagent en boucle depuis le centre.

Au centre, un **téléphone en lévitation** : châssis avec liseré cyan dégradé, encoche,
reflet en diagonale, ligne de scan qui traverse l'écran. Dedans, l'appareil
`sf-cloud-07` en train de publier (barre de progression, proxy `FR-07`, boot `3,2 s`,
petit log ADB). Trois badges flottent autour à des rythmes différents (3,2 s au
démarrage / Illimité / Tes données). Halo pulsant derrière, ombre lumineuse dessous.

Contenu : badge « EN CONSTRUCTION · Q4 2026 », titre « Nos propres **Cloud Phones**
arrivent. », les 3 arguments (Démarrage instantané / Aucune limite / Chez toi), et une
liste d'attente qui passe en confirmation au clic — **8 agences inscrites**, pas un
chiffre gonflé.

### Grille des crédits (`CreditsGrid.tsx`)

Reprend les règles métier réelles de `CLAUDE.md` :

| Action | Coût |
|---|---|
| Publication (par téléphone) | 2 crédits |
| Mass Posting (par téléphone) | 2 crédits |
| Story (par téléphone) | 1 crédit |
| Remix & Spoof (par vidéo) | gratuit |
| Tâche automatique (par jour, tâche active) | 50 crédits |
| Exécution de tâche (par téléphone) | 2 crédits |

Plus un exemple chiffré : 52 comptes = 104 crédits, soit 52 diffusions/mois en plan Pro.

## 1.5 Vérifier

```bash
cd website && npm run dev    # contrôle visuel
npm run build                # doit passer
```

---

# CHANTIER 2 — Application (`electron-app/`)

Pas encore porté en TSX. La spécification complète est dans
`_redesign/handoff/README.md` : tokens exacts, chaque écran en détail,
interactions, état nécessaire, et un tableau screen → fichiers sources.

**Réutilise le design system maison** de `src/index.css` : `sf-card`, `sf-btn`,
`sf-badge`, `sf-page-header`, `sf-page-title`, `sf-section-label`, `sf-status-chip`,
`sf-empty`, `sf-skeleton`, `sf-tabs`/`sf-tab`, et les variables `--text-1`…`--text-4`,
`--surface`, `--border`, `--accent`, `--ok`, `--warn`, `--danger`, `--r-*`, `--sp-*`.

## 2.1 Shell — `src/components/Layout.tsx`

Habillage seul, **ne touche pas** à `isVisibleTab`, `PAGE_PERM_KEY`, ni `canSeeTab`.

Sidebar 232px, fond `rgba(8,8,20,0.85)` + `backdrop-filter: blur(16px)`. Logo + badge de
plan. Bouton de recherche pleine largeur avec raccourci `Ctrl K`. Accueil épinglé en haut.
Groupes identiques à `NAV_SECTIONS` (Principal / Publier / Studio vidéo / Cloud).

Item actif : fond `linear-gradient(135deg, rgba(139,92,246,0.22), rgba(34,211,238,0.10))`,
bordure `rgba(139,92,246,0.35)`, texte `#E9D5FF`, weight 800.

En bas : **raccourci Cloud Phones ScaleFlow** avec badge `SOON` et reflet qui balaye,
puis la carte de crédits (solde en dégradé, jauge, « + Recharger »), puis la ligne
utilisateur.

Le bouton **Blowsome VIP** reste en haut, juste sous Accueil : bouton dégradé
rose→violet→indigo pleine largeur avec badge `VIP` et reflet animé (conserve la logique
`license?.blowsome === true`).

## 2.2 Écrans à redesigner

Chacun est spécifié en détail dans le handoff. Résumé de ce qui change :

| Écran | Points clés |
|---|---|
| **Accueil (Hub)** | 4 KPI teintés, **bannière Cloud Phones** (ondes + reflet + bouton « Réserver mon accès »), actions rapides, deux colonnes Posts à venir / Activité récente |
| **Téléphones** | 4 KPI, recherche, dropdown groupes, filtres, table (# · Téléphone · Groupe · Statut · GéeLark+IP · Actions) |
| **Banque** | onglets de type, pills de dossiers, grille 6 col. de vignettes 9:16, **barre d'actions sticky** sur sélection |
| **Publication** | hub avec les 4 vraies cartes (Reels / Story / Photo « bientôt » / Cross-posting admin), chacune avec un aperçu réaliste |
| **Reels** | **popup bloquant de choix de plateforme à l'entrée** (Instagram / TikTok / Threads, badge « Dernier choix », persisté dans `sf-mp-platform`), puis bandeau plateforme + wizard **4 étapes** : Comptes (dropdown groupes GeeLark) → Vidéos (+ **choix de miniature**) → Légende → Réglages & lancement |
| **Story** | 3 étapes réelles : images (séquentiel/aléatoire) → **pool de textes sticker** → **lien sticker par compte** (« Appliquer à tous »), aperçu de story live, bouton **test gratuit sans publier** |
| **Studio vidéo** | hub 4 outils, puis une page par outil : Remix (sliders + nb de variantes), Spoof (toggles device/GPS/EXIF/empreinte/audio), Sous-titres (langue, position, style du mot fort), Mixer (hooks, position, fond) |
| **Bibliothèque** | lanceur de tâches : téléphones à gauche, **les 10 actions réelles** à droite, suivi live + console de logs |
| **Activité** | sous-onglets Journal / Comptes & Stats |
| **Automatisation** | sous-onglets Programmé (file + calendrier) / Récurrent (tâches avec toggle, sous-étapes, crédits/jour) |
| **Warmup Compte** | 3 onglets `LOG IN` / `MASS EDIT` / `WARMUP`. **LOG IN affiche tous les téléphones** avec un champ identifiant/mot de passe/TOTP par appareil. **WARMUP fonctionne par durée de session** (15 min / 30 min / 1 h / 2 h), pas en cadence horaire — les actions affichent le total estimé sur la durée. **Pas de planification** dans cet onglet |
| **Cloud Phones** | bandeau de statut de l'agent auto-hébergé (CPU/RAM/latence), config URL+token dépliable, 4 KPI (Appareils / Démarrés / Arrêtés / Sessions ADB — **pas de coût ni de comparaison de prix**), table avec sélection multiple et **barre d'actions groupées** |
| **Proxies** | KPI OK/KO/latence, chips de groupes, table (proxy copiable, statut+latence, IP sortante, assignation) |
| **Automatisation UI** | catalogue de flux RPA filtrable par plateforme, badges Vérifié/Beta |
| **Blowsome VIP** | **reste un écran « Bientôt disponible »** — n'invente pas d'onglets. Titre BLOWSOME lettre par lettre en 3D avec dégradé défilant, orbes lumineux, deux ondes concentriques, grille rosée, pastille « Bientôt disponible » à point pulsant, trois arguments (Illimité / Sur mesure / 7j/7) |

## 2.3 Cadences du warmup

Important : les valeurs sont **par heure**, et le total affiché se calcule sur la durée
de session choisie (`Math.round(rate × durée/60)`) :

- Liker des posts : **80/h**
- Regarder des Reels : **120/h**
- Suivre les suggestions : **50/h**

Sur 30 min → ≈ 40 / 60 / 25. Sur 2 h → ≈ 160 / 240 / 100.

## 2.4 Animations dans l'app

**Trois niveaux, tous en CSS — n'écris pas les animations en JS** (React réécrit
l'attribut `style` à chaque re-render et les effacerait).

**1. Boot au lancement.** Overlay plein écran : logo en zoom flouté avec deux anneaux qui
pulsent, barre de chargement, et « connexion à GeeLark · N phones détectés » en
monospace. Disparaît après ~1,9 s.

**2. Transition d'écran.** Chaque conteneur d'écran entre avec
`sfSlideIn` : `rotateX(7deg) translateY(34px) scale(.975)` + flou 6px → état normal,
`0.65s cubic-bezier(0.16,1,0.3,1)`.

**3. Cascade interne.** Règle CSS globale, pas de JS :

```css
@keyframes sfCascade {
  0%   { opacity: 0; transform: translateY(16px) scale(.985); filter: blur(4px) }
  100% { opacity: 1; transform: none; filter: blur(0) }
}
[data-anim-group] > * { animation: sfCascade .6s cubic-bezier(0.16,1,0.3,1) both }
[data-anim-group] > *:nth-child(1)  { animation-delay: 0s }
[data-anim-group] > *:nth-child(2)  { animation-delay: .055s }
/* … jusqu'à nth-child(24), pas de 55 ms … */
@media (prefers-reduced-motion: reduce) { [data-anim-group] > * { animation: none } }
```

Puis pose `data-anim-group` sur les conteneurs à animer (grilles de KPI, de cartes, de
vignettes, listes de lignes). Comme les écrans se remontent au changement d'onglet,
l'animation rejoue automatiquement.

⚠️ **Piège rencontré** : ne pilote pas cette cascade depuis `componentDidUpdate` en
écrivant `el.style.animation`. Ça casse de deux façons — l'inline style est effacé au
re-render suivant, et le hook peut recevoir un `prevState` non défini selon le runtime.
Le CSS pur règle les deux.

**4. Séquence Cloud Phones.** À l'ouverture de l'écran teaser : overlay avec le nuage en
zoom depuis le flou, trois ondes, « INITIALISATION DU CLUSTER », puis le contenu arrive
élément par élément à 100 ms d'écart.

**5. Confirmation d'inscription.** Le bouton devient une pastille verte qui rebondit
(`sfPop`), la coche tourne en arrivant (`sfCheck`), le texte se révèle de gauche à droite
(`sfWipe`), un anneau se propage deux fois, et 16 particules explosent en cercle
(`sfConfetti` avec `--dx`/`--dy` par particule).

## 2.5 Teaser Cloud Phones dans l'app

Les onglets Cloud sont réservés aux admins, donc le hype doit être visible ailleurs :

- **Bannière sur l'Accueil** (tous les utilisateurs) : ondes concentriques, reflet qui
  balaye, badge « BIENTÔT · Q4 2026 », compteur d'agences inscrites, bouton « Réserver
  mon accès → » qui passe en « ✓ Inscrit ».
  ⚠️ Pense à mettre `color` sur le `<button>` — sinon le texte hérite du noir par défaut.
- **Raccourci sidebar** avec badge `SOON`.
- **Écran teaser dédié** : les 3 chiffres (3,2 s / ∞ / 0 $) et une ferme de 64 appareils
  qui bootent en boucle avec le compteur qui monte.

---

---

# LE LOGO

Nouvelle identité, à appliquer **partout** où l'ancienne marque apparaît.

## La marque

Une tuile carrée violette contenant **deux barres blanches de largeur égale, inclinées
dans l'autre sens** — le même contenu, dupliqué. Le rayon à 25 % de la taille la place
dans la famille des icônes d'app qu'elle côtoie.

```tsx
export function LogoMark({ size = 32 }: { size?: number }) {
  const w = Math.round(size * 0.44)
  const h = Math.max(2, Math.round(size * 0.095))
  return (
    <span
      aria-hidden="true"
      className="flex shrink-0 flex-col items-center justify-center"
      style={{
        width: size, height: size,
        gap: Math.max(2, Math.round(size * 0.1)),
        borderRadius: Math.round(size * 0.25),
        background: 'linear-gradient(145deg,#A855F7,#7C3AED)',
        boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.25)',
      }}
    >
      <span style={{ width: w, height: h, borderRadius: 99, background: '#fff', transform: 'skewX(-14deg)' }} />
      <span style={{ width: w, height: h, borderRadius: 99, background: '#fff', transform: 'skewX(14deg)' }} />
    </span>
  )
}
```

## Le mot-symbole

Tout bas de casse, Space Grotesk semibold, `letter-spacing: -0.03em` :
**`scale`** en blanc, **`flow`** en `#A855F7`.

Le composant complet est fourni dans `_redesign/integration/website/src/components/Logo.tsx`
(exporte `LogoMark` et `Logo`).

## Où l'appliquer

| Emplacement | Taille |
|---|---|
| Sidebar de l'app (`Layout.tsx`) | marque 32px + mot 19px |
| Écran de boot de l'app | marque 62px + `SCALEFLOW` espacé (`letter-spacing: 0.4em`) |
| Nav de la landing | marque 32px + mot 19px |
| Intro animée de la landing | marque 52px + `SCALEFLOW` espacé |
| Footer de la landing | marque 30px + mot 17px |
| Écran du téléphone dans la section Cloud Phones | marque 28px |
| `website/public/favicon.svg` | la tuile seule, exportée en SVG |

Remplace aussi l'ancienne icône Electron si elle reprend le motif précédent.

## Tokens visuels (résumé)

Le détail complet est dans le handoff. L'essentiel :

- Fond `#06060E` · surface `rgba(255,255,255,0.025)` · bordure `rgba(255,255,255,0.08)`
- Texte `#F2F0FF` / `rgba(196,181,253,0.72)` / `rgba(148,163,184,0.55)`
- Dégradé de marque `linear-gradient(135deg, #22D3EE, #818CF8, #A855F7)`
- Blowsome : `linear-gradient(90deg, #EC4899, #8B5CF6, #6366F1)`
- Display **Space Grotesk**, corps **Manrope**, technique **monospace**
- Rayons : 10–12px boutons · 16–18px cartes · 20–22px grandes cartes · 99px pills
- Scrollbars : `scrollbar-width: thin` + `scrollbar-color: rgba(139,92,246,0.3) transparent`
  et `::-webkit-scrollbar{width:8px}` — sinon elles ressortent en blanc sur le fond sombre

---

## Ordre de travail recommandé

1. **Landing** (`website/`) — indépendante, aucun risque de régression
2. **Shell** (`Layout.tsx`) — habillage seul
3. **Accueil, Téléphones, Banque** — les écrans les plus vus
4. **Publication → Reels → Story** — le cœur du produit
5. **Studio vidéo + ses 4 outils**
6. **Bibliothèque, Activité, Automatisation**
7. **Cloud Phones, Proxies, Flows, Blowsome**

Après chaque écran, relance le build correspondant.


---

# LIVRAISON — commit et push

Tu fais tout toi-même, dans cet ordre :

```bash
git checkout main && git pull
git checkout -b redesign-scaleflow
```

Puis, **un commit par chantier terminé et vérifié** — jamais un commit fourre-tout :

```bash
# après le chantier 1
cd website && npm run build && cd ..
git add website/
git commit -m "Landing : nouveau hero live, section Cloud Phones, animations au scroll"

# après le shell de l'app
cd electron-app && npm run build:web && cd ..
git add electron-app/src/components/Layout.tsx
git commit -m "App : nouvelle sidebar et nouveau logo"

# … un commit par écran ou par groupe d'écrans …
```

Règles :
- **Le build doit passer avant chaque commit.** `npm run build` dans `website/`,
  `npm run build:web` dans `electron-app/`. S'il échoue, corrige avant de committer.
- Ne committe pas le dossier `_redesign/` : ajoute-le à `.gitignore`, c'est de la
  matière de travail, pas du code de production.
- Ne touche à aucun fichier hors du périmètre décrit ici.

Quand tout est fait :

```bash
git push -u origin redesign-scaleflow
```

Vercel construit automatiquement une **URL de preview** pour la branche. Donne-la à
Quentin et **arrête-toi là** — c'est lui qui décide de merger sur `main`.

Termine en listant : les fichiers créés, les fichiers modifiés, les écrans faits, ceux
qui restent, et tout point où tu as dû trancher toi-même.
